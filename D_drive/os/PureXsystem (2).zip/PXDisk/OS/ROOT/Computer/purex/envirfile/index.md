## PureX ##
purex.system , also known as PureX or pure++ is a complex operating operating system written in bash.
this is in beta , expect some glitches to occur. type cd OS , cd ROOT , cd Computer then cd purex in the 
console for the main folders