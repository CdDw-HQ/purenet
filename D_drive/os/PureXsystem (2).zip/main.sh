python import.py
#OS
echo Copyright Cd-Dw HQ and RAFhub6 Corporation 2021™
echo PureX OS 2.09
echo Type cd PXDisk, cd OS then cd ROOT , cd Computer then cd purex to continue
echo You have "2048 Megabytes/MB" left
echo Source Code : https://github.com/RAFhub6/PureX-System/
cd OS
cd ROOT
cd Computer
cd purex
echo "$Storage"
