<html>
  <head>
    <title>HTTP Tunnel from bash</title>
  </head>
  <body>
    <?php echo '<p>this is a html tunnel from bash</p>'; ?> 
    <?php echo '<a href="https://github.com/RAFhub6/PureX-System"Source Code</a>';